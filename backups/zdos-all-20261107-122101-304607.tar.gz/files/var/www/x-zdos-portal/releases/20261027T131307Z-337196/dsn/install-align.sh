#!/bin/bash
set -euo pipefail
PACK_DIR="${PACK_DIR:-/opt/x-zdos-dsn}"
WORKDIR="${WORKDIR:-/root/zdos-dsn-work}"
mkdir -p "$PACK_DIR"
curl -fsSL https://x-zdos.it/dsn/x-zdos-dsn-align.tar.gz | tar -xzf - -C "$PACK_DIR"
chmod +x "$PACK_DIR/zdos-dsn-align.sh"
WORKDIR="$WORKDIR" "$PACK_DIR/zdos-dsn-align.sh" --profile
