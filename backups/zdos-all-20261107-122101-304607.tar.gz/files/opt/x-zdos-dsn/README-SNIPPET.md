## $DSN · NETkali (ZDOS access layer)

![DSN](https://img.shields.io/badge/%24DSN-NETkali%20%7C%20Polygon-6ee7ff?style=flat-square&labelColor=0b0e16)

Polygon token that unlocks identity & access across the ZDOS stack.

| | |
|---|---|
| Contract | [`0xfc90516a1f736FaC557e09D8853dB80dA192c296`](https://polygonscan.com/token/0xfc90516a1f736FaC557e09D8853dB80dA192c296) |
| Portal | [x-zdos.it/dsn](https://x-zdos.it/dsn) |
| Chain | Polygon |

> Utility first. Liquidity second. Hype never.
