# Super-comando ZDOS × $DSN

Script: `zdos-dsn-align.sh` (dry-run di default; niente push forzato).

## Sulla VPS (GitHub già concesso)

```bash
# dalla cartella pack (o clona/copia /workspace/x-zdos-dsn)
cd /path/to/x-zdos-dsn
chmod +x zdos-dsn-align.sh

# 1) anteprima: verifica on-chain + diff README, nessun write
./zdos-dsn-align.sh

# 2) applica in locale: branch zdos/dsn-align + commit
./zdos-dsn-align.sh --apply

# 3) (opzionale) sync profilo GitHub + push del SOLO branch di align
./zdos-dsn-align.sh --apply --profile --push
# poi apri le PR da GitHub / gh pr create
```

## Cosa fa di autentico

- Verifica in sola lettura che il contract Polygon risponda come `$DSN` / NETkali
- Timbra un blocco marker idempotente nei README prioritari (no spam badge)
- Aggiunge `docs/DSN.md` + frammento stile `os-release` (identità distro)
- Salta fork upstream “estranei” salvo `--include-forks`
- Rispetta `high-cde.github.io` (mai stamp ticker lì)
- Scrive `MANIFEST.md` di cosa cambierebbe / è cambiato

Tono: utility e accesso, non pump. Nessuna affiliazione inventata.
