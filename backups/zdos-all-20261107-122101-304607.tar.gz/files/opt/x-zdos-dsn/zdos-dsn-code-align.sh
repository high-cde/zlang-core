#!/usr/bin/env bash
# zdos-dsn-code-align.sh — allineamento a livello di CODICE dei repo high-cde a $DSN / NETkali.
#
# Complementare a zdos-dsn-align.sh (che timbra i README). Questo script tocca
# config, RPC, env template, il gate on-chain di aesir e il percorso dsn-release
# della distro ZDOS. Solo modifiche meccaniche e verificabili:
#   * RPC morti (rpc.ankr.com/polygon senza chiave, polygon-rpc.com) -> publicnode / dRPC
#   * placeholder 0xDSN_TOKEN_ADDRESS e indirizzo minuscolo -> contratto canonico EIP-55
#   * dsn.env / .env.example con un blocco canonico gestito (chiavi mancanti soltanto)
#   * plugin per ruolo: aesir (dsn_gate), ZDOS (dsn-release nell'ISO), xCLOUD, K.I.R.A, ...
# NON inventa indirizzi, NON rinomina moduli "DSN" interni, NON tocca LICENSE,
# binari, vendor, node_modules, venv. Tutto ciò che richiede giudizio umano finisce
# nella sezione AUDIT del MANIFEST.
#
# Default: dry-run (nessun commit, mostra diff). --apply committa sul branch
# zdos/dsn-code-align (in un git worktree separato: il checkout principale non
# viene toccato). --push richiede --apply. Mai force-push.
set -Eeuo pipefail

readonly VERSION="1"
readonly DSN_NAME="NETkali"
readonly DSN_SYMBOL='$DSN'
readonly DSN_CHAIN="Polygon PoS"
readonly DSN_CHAIN_ID=137
readonly DSN_DECIMALS=18
readonly DSN_CONTRACT="0xfc90516a1f736FaC557e09D8853dB80dA192c296"
readonly DSN_PORTAL="https://x-zdos.it/dsn"
readonly DSN_EXPLORER="https://polygonscan.com/token/${DSN_CONTRACT}"
readonly RPC_PRIMARY="https://polygon-bor-rpc.publicnode.com"
readonly RPC_FALLBACK="https://polygon.drpc.org"
readonly GH_OWNER="high-cde"
readonly BRANCH="zdos/dsn-code-align"
readonly MARK="zdos-dsn-code-align v${VERSION}"

# Ordine = repo più lavorati (commit/codice reale) per primi.
DEFAULT_REPOS="aesir ZDOS xCLOUD-by-zdos zdos-hybrid Z-GENESIS-OS Zlang Zdos-K.I.R.A zdos-organism z-valut zBAG zdos-core xzdos-unified-webapp x-zdos.it zlang-core"
# Fork di upstream: niente regole generiche, solo il plugin dedicato (se esiste).
UPSTREAM_FORKS="zBAG zclipper zdosBOT kaliZ base-K.I.R.A ai-K.I.R.A K.I.R.A Z-GENESIS-OS xCLOUD-by-zdos"
NEVER_TOUCH="high-cde.github.io"

WORKDIR="${WORKDIR:-$HOME/zdos-dsn-work}"
APPLY=0; PUSH=0; USE_SSH=0; VERIFY=1; FETCH=1
UNTRACK_ARTIFACTS=0; UNTRACK_SECRETS=0
REPOS="$DEFAULT_REPOS"

log()  { printf '\033[1;36m[dsn-code]\033[0m %s\n' "$*"; }
ok()   { printf '\033[1;32m[ ok ]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[warn]\033[0m %s\n' "$*" >&2; }
die()  { printf '\033[1;31m[fail]\033[0m %s\n' "$*" >&2; exit 1; }
# shellcheck disable=SC2048,SC2086  # split intenzionale delle liste di repo
in_list() { local x="$1"; shift; for i in $*; do [[ "$i" == "$x" ]] && return 0; done; return 1; }

usage() {
cat <<EOF
Uso: $0 [opzioni]
  (nessuna opzione)      dry-run: clona/aggiorna in \$WORKDIR, mostra diff + MANIFEST, non committa
  --apply                committa su branch $BRANCH (worktree separato, checkout principale intatto)
  --push                 push del branch su origin (richiede --apply; mai --force)
  --repos "a b c"        sottoinsieme di repo (default: $DEFAULT_REPOS)
  --workdir DIR          dove stanno i clone (default: \$HOME/zdos-dsn-work)
  --ssh                  clona via git@github.com: (serve per --push)
  --no-verify            salta la verifica on-chain del contratto
  --no-fetch             usa i clone locali così come sono (offline)
  --untrack-artifacts    git rm --cached di venv/target/__pycache__ committati + .gitignore
  --untrack-secrets      git rm --cached di wallet/chiavi committati (Zlang/node_wallet.zbag) + .gitignore
                         (NON riscrive la storia: la chiave resta compromessa, va ruotata)
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --apply) APPLY=1 ;;
    --push) PUSH=1 ;;
    --repos) REPOS="${2:?}"; shift ;;
    --workdir) WORKDIR="${2:?}"; shift ;;
    --ssh) USE_SSH=1 ;;
    --no-verify) VERIFY=0 ;;
    --no-fetch) FETCH=0 ;;
    --untrack-artifacts) UNTRACK_ARTIFACTS=1 ;;
    --untrack-secrets) UNTRACK_SECRETS=1 ;;
    -h|--help) usage; exit 0 ;;
    *) usage >&2; die "opzione sconosciuta: $1" ;;
  esac
  shift
done
[[ $PUSH -eq 1 && $APPLY -eq 0 ]] && die "--push richiede --apply"
for b in git python3 curl; do command -v "$b" >/dev/null || die "manca $b"; done
mkdir -p "$WORKDIR"
WORKDIR="$(cd "$WORKDIR" && pwd)"
TMP="$(mktemp -d)"
cleanup() {
  local d
  for d in "$TMP"/wt/*; do
    [[ -d "$d" ]] || continue
    git -C "$(cat "$d.repo" 2>/dev/null || echo /nonexistent)" worktree remove --force "$d" >/dev/null 2>&1 || true
  done
  for d in "$TMP"/wt/*.repo; do [[ -f "$d" ]] && git -C "$(cat "$d")" worktree prune >/dev/null 2>&1 || true; done
  rm -rf "$TMP"
}
trap cleanup EXIT
mkdir -p "$TMP/wt"

# ---------------------------------------------------------------- on-chain
abi_string() { python3 -c '
import sys
h=sys.argv[1][2:]
try:
    off=int(h[:64],16)*2; n=int(h[off:off+64],16); print(bytes.fromhex(h[off+64:off+64+n*2]).decode())
except Exception: print("")' "$1"; }
eth_call() { # rpc data -> result hex o vuoto (gli errori JSON-RPC con HTTP 200 contano come errore)
  curl -fsS -m 10 -H 'content-type: application/json' \
    -d "{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"eth_call\",\"params\":[{\"to\":\"$DSN_CONTRACT\",\"data\":\"$2\"},\"latest\"]}" "$1" 2>/dev/null \
  | python3 -c 'import sys,json
try: d=json.load(sys.stdin); print(d["result"] if "result" in d and "error" not in d else "")
except Exception: print("")'; }
verify_chain() {
  local rpc sym name dec
  for rpc in "$RPC_PRIMARY" "$RPC_FALLBACK"; do
    sym="$(abi_string "$(eth_call "$rpc" 0x95d89b41)")"
    [[ -n "$sym" ]] || continue
    name="$(abi_string "$(eth_call "$rpc" 0x06fdde03)")"
    dec="$(python3 -c 'import sys;print(int(sys.argv[1],16))' "$(eth_call "$rpc" 0x313ce567)" 2>/dev/null || echo '?')"
    if [[ "$sym" == "$DSN_SYMBOL" && "$dec" == "$DSN_DECIMALS" ]]; then
      ok "on-chain: symbol=$sym name=$name decimals=$dec via $rpc"; return 0
    fi
    die "on-chain mismatch: symbol=$sym decimals=$dec (attesi $DSN_SYMBOL/$DSN_DECIMALS)"
  done
  die "nessun RPC risponde (usa --no-verify per lavorare offline)"
}
[[ $VERIFY -eq 1 ]] && verify_chain || warn "verifica on-chain saltata"

# ---------------------------------------------------------------- templates
mkdir -p "$TMP/tpl"
cat > "$TMP/tpl/dsn_gate.py" <<'GATE_EOF'
#!/usr/bin/env python3
# ZDOS:DSN-CODE-ALIGN v1 — managed by zdos-dsn-code-align.sh (aesir plugin).
# $DSN / NETkali: ERC-20 on Polygon PoS (chain id 137), 18 decimals.
# Contract 0xfc90516a1f736FaC557e09D8853dB80dA192c296 · portal https://x-zdos.it/dsn
# Access layer only: read-only balanceOf, no keys, no transactions.
import os, requests, time
from pathlib import Path

_HERE = Path(__file__).resolve().parent


def _readable(p: Path) -> bool:
    try:
        return p.is_file() and os.access(p, os.R_OK)
    except OSError:  # e.g. /root not traversable for non-root users
        return False

_LEGACY_ENV = Path("/root/zdos-aesir/aesir/dsn.env")
ENV_PATH = Path(os.getenv("DSN_ENV", str(_HERE / "dsn.env")))
if not _readable(ENV_PATH) and _readable(_LEGACY_ENV):
    ENV_PATH = _LEGACY_ENV
if _readable(ENV_PATH):
    for line in ENV_PATH.read_text().splitlines():
        line = line.strip()
        if "=" in line and not line.startswith("#"):
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip())

DSN = os.getenv("DSN_CONTRACT", "0xfc90516a1f736FaC557e09D8853dB80dA192c296")
CHAIN_ID = int(os.getenv("DSN_CHAIN_ID", "137"))
# rpc.ankr.com/polygon and polygon-rpc.com now require an API key and answer
# with a JSON-RPC error (ankr even with HTTP 200): never use them as defaults.
_RPC_CANDIDATES = [
    os.getenv("POLYGON_RPC", "https://polygon-bor-rpc.publicnode.com"),
    os.getenv("POLYGON_RPC_FALLBACK", "https://polygon.drpc.org"),
    "https://polygon-bor-rpc.publicnode.com",
    "https://polygon.drpc.org",
]
RPCS = list(dict.fromkeys(u for u in _RPC_CANDIDATES if u))
MIN_WEI = int(os.getenv("DSN_MIN_BALANCE_WEI", "1000000000000000000"))
HIGH_WEI = int(os.getenv("DSN_HIGH_LIMIT_WEI", "10000000000000000000"))
_CHAIN_OK = {}


class RPCError(Exception):
    pass


def _call(rpc, method, params):
    r = requests.post(rpc, json={"jsonrpc": "2.0", "id": 1, "method": method, "params": params}, timeout=6)
    r.raise_for_status()
    body = r.json()
    # A JSON-RPC error must NOT be read as "balance 0": try the next endpoint.
    if not isinstance(body, dict) or "error" in body or "result" not in body:
        raise RPCError(f"{rpc}: {body.get('error') if isinstance(body, dict) else body}")
    return body["result"]


def _chain_ok(rpc) -> bool:
    if rpc not in _CHAIN_OK:
        try:
            _CHAIN_OK[rpc] = int(_call(rpc, "eth_chainId", []), 16) == CHAIN_ID
        except Exception:
            return False
    return _CHAIN_OK[rpc]


def get_balance(address: str) -> int:
    """balanceOf(address) in wei; 0 if the address is malformed or every RPC fails (fail-closed)."""
    if not isinstance(address, str) or not address.startswith("0x") or len(address) != 42:
        return 0
    try:
        int(address[2:], 16)
    except ValueError:
        return 0
    data = "0x70a08231" + address[2:].lower().zfill(64)
    for rpc in RPCS:
        if not _chain_ok(rpc):
            continue
        try:
            return int(_call(rpc, "eth_call", [{"to": DSN, "data": data}, "latest"]), 16)
        except Exception:
            continue
    return 0


def has_min_dsn(address: str, min_wei=None) -> bool:
    return get_balance(address) >= (MIN_WEI if min_wei is None else min_wei)


def get_limit_for(address: str) -> int:
    bal = get_balance(address)
    if bal >= HIGH_WEI:
        return int(os.getenv("DSN_HOURLY_BOOSTED", "5000000000"))
    if bal >= MIN_WEI:
        return int(os.getenv("DSN_HOURLY_BASE", "500000000"))
    return 0
GATE_EOF

cat > "$TMP/tpl/test-dsn-release.sh" <<'TEST_EOF'
#!/usr/bin/env bash
# zdos-dsn-code-align v1 — contract test: /etc/zdos/dsn-release è canonico e finisce nell'ISO.
set -Eeuo pipefail
ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
REL="$ROOT/distro/rootfs/etc/zdos/dsn-release"
BUILD="$ROOT/distro/build.sh"
fail() { printf 'ZDOS_DSN_RELEASE_CONTRACT_FAILED: %s\n' "$1" >&2; exit 1; }
test -r "$REL" || fail 'dsn-release assente'
grep -Fqx 'DSN_CONTRACT=0xfc90516a1f736FaC557e09D8853dB80dA192c296' "$REL" || fail 'contratto non canonico'
grep -Fqx 'DSN_CHAIN_ID=137' "$REL" || fail 'chain id non 137'
grep -Fqx 'DSN_DECIMALS=18' "$REL" || fail 'decimali non 18'
grep -Fqx 'DSN_REQUIRED_TO_BOOT=no' "$REL" || fail 'il boot non deve dipendere da $DSN'
! grep -Eiq '(private|secret|mnemonic|seed)' "$REL" || fail 'materiale segreto in dsn-release'
grep -Fq '"$DISTRO/rootfs/etc/zdos/dsn-release" "$ROOTFS/etc/zdos/dsn-release"' "$BUILD" || fail 'build.sh non copia dsn-release'
printf 'ZDOS_DSN_RELEASE_CONTRACT_OK\n'
TEST_EOF

# ---------------------------------------------------------------- engine
cat > "$TMP/engine.py" <<'ENGINE_EOF'
import hashlib, json, os, re, subprocess, sys
from pathlib import Path

C = dict(os.environ)
REPO, ROOT, TPL = sys.argv[1], Path(sys.argv[2]), Path(sys.argv[3])
IS_FORK = C["IS_FORK"] == "1"
CONTRACT = C["DSN_CONTRACT"]; RPC1 = C["RPC_PRIMARY"]; RPC2 = C["RPC_FALLBACK"]
MARK = C["MARK"]
UNTRACK_ART = C["UNTRACK_ARTIFACTS"] == "1"; UNTRACK_SEC = C["UNTRACK_SECRETS"] == "1"
# Indirizzi sbagliati realmente trovati nei repo (audit 2026-11): nessuno.
# Si possono aggiungere a runtime: DSN_KNOWN_BAD="0xabc... 0xdef..."
KNOWN_BAD = [a for a in C.get("DSN_KNOWN_BAD", "").split() if re.fullmatch(r"0x[0-9a-fA-F]{40}", a)]
OLD_GATE_SHA = {"c25da940d8efbb31ae06bbe21c360d714d8616a84784530b7e18540f69d52a34"}

SKIP_DIR = re.compile(r"(^|/)(\.git|node_modules|vendor|third_party|dist|build|target|site-packages|zdos-llm|\.?venv|env|__pycache__|\.zlang-backups|Pods|android|ios)(/|$)")
SKIP_FILE = re.compile(r"(\.min\.(js|css)|bundle[^/]*\.js|InjectedJSBundle\.js|package-lock\.json|pnpm-lock\.yaml|yarn\.lock|Cargo\.lock|uv\.lock|poetry\.lock|\.map)$|(^|/)(LICENSE|COPYING)[^/]*$", re.I)
HASH_COMMENT = {".py", ".sh", ".bash", ".rb", ".toml", ".yml", ".yaml", ".conf"}
SLASH_COMMENT = {".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".rs", ".go", ".zl", ".c", ".h", ".java"}
DOC_EXT = {".md", ".html", ".htm", ".txt", ".rst"}

changed = {}
def emit(kind, **kw):
    kw["type"] = kind; print(json.dumps(kw, ensure_ascii=False), flush=True)
def change(path, rule, detail):
    emit("change", file=path, rule=rule, detail=detail); changed[path] = True
def finding(sev, path, msg):
    emit("finding", sev=sev, file=path, msg=msg)
def untrack(path, why):
    emit("untrack", file=path, why=why)

def tracked():
    out = subprocess.run(["git", "-C", str(ROOT), "ls-files", "-z"], capture_output=True, check=True).stdout
    return [p for p in out.decode("utf-8", "replace").split("\0") if p]
FILES = tracked()

def is_text(p: Path):
    try:
        if p.is_symlink() or not p.is_file() or p.stat().st_size > 1_000_000: return False
        b = p.read_bytes()[:8192]
        if b"\0" in b: return False
        b.decode("utf-8"); return True
    except Exception:
        return False
def read(rel): return (ROOT / rel).read_text(encoding="utf-8")
def write(rel, s):
    p = ROOT / rel; p.parent.mkdir(parents=True, exist_ok=True)
    mode = p.stat().st_mode if p.exists() else None
    p.write_text(s, encoding="utf-8")
    if mode is not None: os.chmod(p, mode)
def sha(s): return hashlib.sha256(s.encode()).hexdigest()

# ---------------- managed env block
def env_block(keys):
    lines = [f"# >>> ZDOS:DSN-CODE-ALIGN v{C['VERSION']} — $DSN / NETkali (access layer). Generato da zdos-dsn-code-align.sh",
             "# Riferimento: " + C["DSN_PORTAL"] + " · " + C["DSN_EXPLORER"]]
    lines += [f"{k}={v}" for k, v in keys]
    lines.append("# <<< ZDOS:DSN-CODE-ALIGN")
    return "\n".join(lines) + "\n"
BLOCK_RE = re.compile(r"# >>> ZDOS:DSN-CODE-ALIGN.*?# <<< ZDOS:DSN-CODE-ALIGN\n?", re.S)
def ensure_env(rel, wanted, create=True):
    p = ROOT / rel
    if not p.exists() and not create: return
    s = read(rel) if p.exists() else ""
    outside = BLOCK_RE.sub("", s)
    defined = {m.group(1): m.group(2) for m in re.finditer(r"^\s*(?:export\s+)?([A-Z0-9_]+)\s*=\s*(.*)$", outside, re.M)}
    for k, v in wanted:
        if k in defined and k == "DSN_CONTRACT" and defined[k].strip().strip('"\'') not in (CONTRACT, ""):
            finding("HIGH", rel, f"DSN_CONTRACT={defined[k].strip()} non canonico: verificare a mano")
    missing = [(k, v) for k, v in wanted if k not in defined]
    new_block = env_block(missing) if missing else ""
    if BLOCK_RE.search(s): new = BLOCK_RE.sub(new_block, s)
    else: new = s + ("" if s.endswith("\n") or not s else "\n") + ("\n" if s else "") + new_block
    if new != s:
        write(rel, new)
        change(rel, "env-template", ("creato" if not s else "blocco canonico") + ": " + ", ".join(k for k, _ in missing))

CANON_ENV = [("DSN_CONTRACT", CONTRACT), ("DSN_CHAIN_ID", C["DSN_CHAIN_ID"]), ("DSN_DECIMALS", C["DSN_DECIMALS"]),
             ("POLYGON_RPC", RPC1), ("POLYGON_RPC_FALLBACK", RPC2), ("DSN_PORTAL_URL", C["DSN_PORTAL"])]

def ensure_gitignore(rel_dir, patterns, why):
    rel = (rel_dir + "/.gitignore").lstrip("/") if rel_dir else ".gitignore"
    p = ROOT / rel
    s = read(rel) if p.exists() else ""
    have = {l.strip() for l in s.splitlines()}
    add = [x for x in patterns if x not in have]
    if add:
        s2 = s + ("" if s.endswith("\n") or not s else "\n") + f"# {MARK}: {why}\n" + "\n".join(add) + "\n"
        write(rel, s2); change(rel, "gitignore", ", ".join(add))

def committed_under(prefix_re):
    r = re.compile(prefix_re)
    return [f for f in FILES if r.search(f)]

def untrack_dirs(prefix_re, label):
    hits = committed_under(prefix_re)
    if not hits: return
    if UNTRACK_ART:
        untrack_list = sorted({m.group(0).rstrip("/") for f in hits for m in [re.search(prefix_re, f)] if m})
        for u in untrack_list: untrack(u, label)
    else:
        finding("MED", "", f"{len(hits)} file di {label} committati (usa --untrack-artifacts)")

# ---------------- generic rules
ANKR = re.compile(r"https?://rpc\.ankr\.com/polygon(?![\w/-])")
POLYRPC = re.compile(r"https?://polygon-rpc\.com/?(?![\w.-])")
PLACEHOLDER = re.compile(r"0xDSN_TOKEN_ADDRESS")
LOWER = re.compile(r"0x" + CONTRACT[2:], re.I)
DSN_PHRASE = re.compile(r"Data Sovereignty Network")
HEREDOC = re.compile(r"<<-?\s*['\"]?([A-Za-z_][A-Za-z0-9_]*)['\"]?")

def comment_prefix(ext, line):
    s = line.lstrip()
    if ext in HASH_COMMENT or ext in {".env", ""}: return s.startswith("#")
    if ext in SLASH_COMMENT: return s.startswith(("//", "/*", "*"))
    return False

def marker_ok(ext, line):
    if len(line) > 300 or line.rstrip().endswith("\\"): return False
    if ext == ".py" and (line.count('"""') % 2 or line.count("'''") % 2): return False
    if ext in {".js", ".mjs", ".cjs", ".ts", ".jsx", ".tsx"} and line.count("`") % 2: return False
    return ext in HASH_COMMENT or ext in {".js", ".mjs", ".cjs", ".ts", ".jsx", ".tsx", ".rs", ".go"}

def generic(rel, allow_long=False):
    p = ROOT / rel
    if SKIP_DIR.search(rel) or SKIP_FILE.search(rel) or not is_text(p): return
    s = read(rel)
    if not (ANKR.search(s) or POLYRPC.search(s) or PLACEHOLDER.search(s) or LOWER.search(s) or DSN_PHRASE.search(s)
            or any(b.lower() in s.lower() for b in KNOWN_BAD)): return
    ext = p.suffix.lower()
    name = p.name
    is_env = name.startswith(".env") or name.endswith(".env") or ext == ".env"
    out, heredoc = [], None
    for line in s.split("\n"):
        if len(line) > 1000 and not allow_long:
            out.append(line); continue
        if heredoc and line.strip() == heredoc:
            heredoc = None; out.append(line); continue
        orig, rules = line, []
        line2 = ANKR.sub(RPC1, line)
        if line2 != line: rules.append("rpc:ankr->publicnode")
        line3 = POLYRPC.sub(RPC2, line2)
        if line3 != line2: rules.append("rpc:polygon-rpc.com->drpc")
        line4 = PLACEHOLDER.sub(CONTRACT, line3)
        if line4 != line3: rules.append("placeholder->contratto")
        line5 = LOWER.sub(lambda m: CONTRACT if m.group(0) != CONTRACT else m.group(0), line4)
        if line5 != line4: rules.append("checksum EIP-55")
        for bad in KNOWN_BAD:
            l6 = re.sub(re.escape(bad), CONTRACT, line5, flags=re.I)
            if l6 != line5: rules.append(f"contratto errato {bad[:10]}…->canonico"); line5 = l6
        if DSN_PHRASE.search(line5) and (ext in DOC_EXT or comment_prefix(ext, line5)):
            line5 = DSN_PHRASE.sub("rete di accesso NETkali", line5); rules.append("wording NETkali")
        if line5 != orig:
            rpc_rule = any("rpc" in r for r in rules)
            if rpc_rule and is_env and not heredoc:
                indent = re.match(r"\s*", line5).group(0)
                out.append(f"{indent}# {MARK}: endpoint precedente richiede API key / non risponde più")
            elif rpc_rule and not heredoc and marker_ok(ext, line5):
                tok = "#" if ext in HASH_COMMENT else "//"
                line5 = f"{line5}  {tok} {MARK}"
            change(rel, "+".join(dict.fromkeys(rules)), orig.strip()[:110] + "  =>  " + line5.strip()[:110])
        out.append(line5)
        if ext in {".sh", ".bash"} and not heredoc:
            m = HEREDOC.search(line5)
            if m and "<<<" not in line5: heredoc = m.group(1)
    new = "\n".join(out)
    if new != s: write(rel, new)

# ---------------- scans (solo report, nessuna modifica)
SCANS = [
    ("CRIT", re.compile(r"[\"']?(private_?key|privateKey|secret_?key)[\"']?\s*[:=]\s*[\"']?(0x)?[0-9a-fA-F]{64}\\b", re.I), "chiave privata in chiaro (valore NON mostrato)"),
    ("CRIT", re.compile(r"[\"'](mnemonic|seed_?phrase)[\"']\s*:\s*[\"']([a-z]+ ){11,23}[a-z]+[\"']", re.I), "mnemonic in chiaro (valore NON mostrato)"),
    ("MED", re.compile(r"polygon\.llamarpc\.com|1rpc\.io/matic"), "RPC che non risponde in modo affidabile (lasciato come fallback, verificare)"),
    ("MED", re.compile(r"chain_id\s*[:=]\s*7777"), "chain 7777 ≠ Polygon 137 dove vive $DSN"),
    ("MED", re.compile(r"0x[A-Z][A-Z_]{4,}_ADDRESS"), "placeholder di indirizzo senza valore reale"),
    ("LOW", re.compile(r"dexscreener", re.I), "ticker di prezzo: tono/area finanziaria, decisione umana"),
    ("LOW", re.compile(r"\b(DSN-LIVE|DSN-CORE|DSN-PALACE|dsn_ledger|zDSN|Distributed Service Network|Dynamic Signal Network|DSN-Immutable)"), "nome 'DSN' interno con significato diverso dal token: NON rinominato automaticamente"),
    ("MED", re.compile(r"simulat[oa]|Simulazione|\bmock(ed)?\b", re.I), "logica simulata (non on-chain)"),
]
def scan_all():
    agg = {}
    for rel in FILES:
        if SKIP_DIR.search(rel) or SKIP_FILE.search(rel): continue
        p = ROOT / rel
        if not is_text(p): continue
        s = read(rel)
        for sev, rx, msg in SCANS:
            n = len(rx.findall(s))
            if not n: continue
            if sev == "CRIT" and re.search(r"(^|/)(tests?|__tests__|fixtures?)/|\.(test|spec)\.[jt]sx?$", rel):
                sev, msg = "LOW", "chiave di test/fixture (probabilmente pubblica, verificare)"
            agg.setdefault((sev, msg), []).append(f"{rel}({n})")
    for (sev, msg), where in agg.items():
        if sev == "MED" and msg.startswith("logica simulata") and len(where) > 6:
            finding(sev, "", f"{msg}: {len(where)} file, es. " + ", ".join(where[:4]))
        else:
            finding(sev, "", f"{msg}: " + ", ".join(where[:8]) + (f" (+{len(where)-8})" if len(where) > 8 else ""))

# ---------------- plugins
OWNED = set()

def plug_aesir():
    if "dsn_gate.py" in FILES:
        s = read("dsn_gate.py"); tpl = (TPL / "dsn_gate.py").read_text()
        if s == tpl: pass
        elif sha(s) in OLD_GATE_SHA:
            write("dsn_gate.py", tpl); OWNED.add("dsn_gate.py")
            change("dsn_gate.py", "aesir:gate-rewrite", "RPC publicnode/dRPC, errore JSON-RPC ≠ saldo 0, check chainId 137, DSN_ENV, /root non leggibile gestito")
        else:
            finding("HIGH", "dsn_gate.py", "hash non riconosciuto: patch manuale (bug: errore RPC letto come saldo 0)")
    if "aesir-advance.sh" in FILES:
        s = read("aesir-advance.sh"); tpl = (TPL / "dsn_gate.py").read_text()
        m = re.search(r"(cat > dsn_gate\.py << 'EOF'\n)(.*?\n)(EOF\n)", s, re.S)
        if m and sha(m.group(2)) in OLD_GATE_SHA:
            s2 = s[:m.start(2)] + tpl + s[m.end(2):]
            write("aesir-advance.sh", s2); OWNED.add("aesir-advance.sh")
            change("aesir-advance.sh", "aesir:heredoc-gate", "heredoc dsn_gate.py = nuovo template (altrimenti rieseguire advance annullerebbe il fix)")
        elif m and m.group(2) != tpl:
            finding("HIGH", "aesir-advance.sh", "heredoc dsn_gate.py diverso dal noto: allineare a mano")
    if "dsn.env" in FILES:
        generic("dsn.env"); OWNED.add("dsn.env")
        ensure_env("dsn.env", CANON_ENV, create=False)
    for rel, depth in (("status_server.py", 0), ("zlang_dsn_helper.py", 0), ("hybrid/hybrid_core.py", 1)):
        if rel not in FILES: continue
        s = read(rel); legacy = 'sys.path.insert(0, "/root/zdos-aesir/aesir")\n'
        here = "Path(__file__).resolve().parent" + (".parent" * depth)
        newl = f'sys.path.insert(0, os.environ.get("AESIR_HOME") or str({here}))  # {MARK}: non solo /root\n'
        if legacy in s and newl not in s and "from pathlib import Path" in s:
            s2 = s.replace(legacy, legacy + ("import os\n" if not re.search(r"^import .*\bos\b", s, re.M) else "") + newl, 1)
            write(rel, s2); change(rel, "aesir:import-path", "dsn_gate importabile da qualsiasi path di installazione")
    ensure_gitignore("", ["__pycache__/", "*.pyc", "policy/target/"], "artefatti di build")
    untrack_dirs(r"^(.*/)?__pycache__(?=/)|^policy/target(?=/)", "artefatti (target/__pycache__)")

def render_release():
    return "\n".join([
        f"# /etc/zdos/dsn-release — {MARK}. Formato os-release, solo dati pubblici.",
        "ZDOS_ID=zdos", 'ZDOS_NAME="ZDOS Linux"', "ZDOS_VARIANT_ID=experimental",
        "ZDOS_HOME_URL=https://x-zdos.it", 'ZDOS_IDENTITY_ROOT="did:zdos (Ed25519, local)"',
        f"DSN_NAME={C['DSN_NAME']}", "DSN_SYMBOL='$DSN'", "DSN_STANDARD=ERC-20",
        f'DSN_CHAIN="{C["DSN_CHAIN"]}"', f"DSN_CHAIN_ID={C['DSN_CHAIN_ID']}", f"DSN_DECIMALS={C['DSN_DECIMALS']}",
        f"DSN_CONTRACT={CONTRACT}", f"DSN_PORTAL_URL={C['DSN_PORTAL']}", f"DSN_EXPLORER_URL={C['DSN_EXPLORER']}",
        f"DSN_RPC_URL={RPC1}", f"DSN_RPC_FALLBACK_URL={RPC2}",
        'DSN_ROLE="access,identity"', "DSN_REQUIRED_TO_BOOT=no", ""])

def plug_zdos():
    rel = "distro/rootfs/etc/zdos/dsn-release"
    if not (ROOT / "distro/build.sh").exists():
        finding("HIGH", "distro/build.sh", "assente: percorso distro cambiato, plugin saltato"); return
    want = render_release(); cur = read(rel) if (ROOT / rel).exists() else None
    if cur is None or (cur != want and "zdos-dsn" in cur):
        write(rel, want); change(rel, "zdos:dsn-release", "creato" if cur is None else "aggiornato")
    elif cur != want:
        finding("MED", rel, "esiste ma non è gestito dallo script: confrontare a mano")
    b = read("distro/build.sh")
    anchor = 'cp "$DISTRO/rootfs/etc/zdos/organism.conf" "$ROOTFS/etc/zdos/organism.conf"\n'
    cpl = f'cp "$DISTRO/rootfs/etc/zdos/dsn-release" "$ROOTFS/etc/zdos/dsn-release"  # {MARK}\n'
    chm = f'chmod 0644 "$ROOTFS/etc/zdos/dsn-release"  # {MARK}\n'
    if '"$DISTRO/rootfs/etc/zdos/dsn-release"' not in b:
        if anchor in b:
            b = b.replace(anchor, anchor + cpl, 1)
            lines = b.split("\n"); idx = next((i for i, l in enumerate(lines) if l.startswith("chmod 0644") and "organism.conf" in l), None)
            if idx is not None: lines.insert(idx + 1, chm.rstrip("\n"))
            else: finding("MED", "distro/build.sh", "riga chmod 0644 non trovata: permessi dsn-release da verificare")
            write("distro/build.sh", "\n".join(lines)); change("distro/build.sh", "zdos:iso-path", "dsn-release copiato in /etc/zdos dell'ISO (+chmod 0644)")
        else:
            finding("HIGH", "distro/build.sh", "anchor organism.conf non trovato: aggiungere a mano la copia di dsn-release")
    t = "distro/test-dsn-release.sh"; tpl = (TPL / "test-dsn-release.sh").read_text()
    if not (ROOT / t).exists() or read(t) != tpl:
        write(t, tpl); os.chmod(ROOT / t, 0o755); change(t, "zdos:contract-test", "test contratto dsn-release")
    st = "tools/zdos-selftest.sh"
    if (ROOT / st).exists():
        s = read(st); hook = "run_check 'distro DSN release contract' bash distro/test-dsn-release.sh\n"
        a = "run_check 'distro hardware baseline contract' bash distro/test-hardware-contract.sh\n"
        if hook not in s and a in s:
            write(st, s.replace(a, a + hook, 1)); change(st, "zdos:selftest-hook", "esegue test-dsn-release.sh")

def plug_xcloud():
    for rel in ("config/chain.config.js", "update.sh"):
        if rel not in FILES: continue
        generic(rel, allow_long=True); OWNED.add(rel); s = read(rel)
        if "chainId" not in s:
            s2 = re.sub(r'(network:\s*"polygon",)(\s*)', lambda m: m.group(1) + m.group(2) + "chainId: 137," + (m.group(2) or " ") + "dsnDecimals: 18," + (m.group(2) or " ") + f'dsnPortal: "{C["DSN_PORTAL"]}",' + (m.group(2) or ""), s, count=1)
            if s2 != s: write(rel, s2); change(rel, "xcloud:chain-config", "aggiunti chainId 137, dsnDecimals 18, dsnPortal")
        if "0xBUSINESS_REGISTRY_ADDRESS" in s:
            finding("MED", rel, "businessRegistryAddress è un placeholder: nessun contratto reale noto, NON inventato")
    if "services/chainAdapter.js" in FILES:
        finding("MED", "services/chainAdapter.js", "recordOnChain è uno stub (solo log): nessuna scrittura on-chain reale")
    ensure_env(".env.example", [("DSN_ENABLED", "false")] + CANON_ENV, create=True)

def plug_kira():
    ensure_env("backend/.env.example" if (ROOT / "backend").is_dir() else ".env.example",
               CANON_ENV + [("DSN_GATE_ENABLED", "false"), ("DSN_MIN_BALANCE_WEI", "1000000000000000000")], create=True)
    finding("LOW", "backend/", "il backend non legge ancora DSN_*: il gate va implementato (lavoro di sviluppo, non meccanico)")

def plug_hybrid():
    finding("HIGH", "zdos_omni_os.py", "risposta 'AUTHORIZED' senza verifica balanceOf: gate finto, da collegare a un vero controllo")
    ensure_env(".env.example", CANON_ENV, create=True)
    untrack_dirs(r"^zdos-llm(?=/)", "virtualenv Python (zdos-llm/)")
    ensure_gitignore("", ["zdos-llm/", "__pycache__/"], "virtualenv e cache")

def plug_organism():
    untrack_dirs(r"^(.*/)?(venv|\.venv|zdos-llm|site-packages)(?=/)|^(.*/)?__pycache__(?=/)", "virtualenv/cache")
    ensure_gitignore("", ["zdos-llm/", "venv/", ".venv/", "__pycache__/"], "virtualenv e cache")

def plug_genesis():
    rel = "index.html"
    if rel not in FILES: return
    s = read(rel)
    old = ('"<p><strong>Prezzo:</strong> 0.0000X USD</p>" +\n'
           '          "<p><strong>Volume 24h:</strong> 0.00 USD</p>" +\n'
           '          "<p><strong>Liquidity:</strong> in fase di evocazione...</p>" +\n'
           '          "<p><strong>Stato:</strong> monitor concettuale attivo.</p>";')
    new = ('"<p><strong>Token:</strong> $DSN / NETkali · ERC-20 su Polygon PoS (chain 137), 18 decimali</p>" +\n'
           f'          "<p><strong>Contratto:</strong> <code>{CONTRACT}</code></p>" +\n'
           f'          "<p><strong>Explorer:</strong> <a href=\\"{C["DSN_EXPLORER"]}\\">Polygonscan</a> · <a href=\\"{C["DSN_PORTAL"]}\\">x-zdos.it/dsn</a></p>" +\n'
           '          "<p><strong>Ruolo:</strong> layer di accesso e identità (nessun dato di prezzo mostrato).</p>"; // ' + MARK)
    if old in s:
        write(rel, s.replace(old, new, 1)); OWNED.add(rel); change(rel, "genesis:dsn-monitor", "prezzo/volume fittizi -> dati canonici statici")
    elif "0.0000X USD" in s:
        finding("MED", rel, "monitor $DSN con valori fittizi ma forma diversa: correggere a mano")

def plug_zlang():
    if "node_wallet.zbag" in FILES:
        finding("CRIT", "node_wallet.zbag", "wallet con chiave privata e mnemonic committato in repo PUBBLICO: considerarlo compromesso, ruotare, non usarlo. Rimozione dalla storia = force-push (decisione umana)")
        ensure_gitignore("", ["node_wallet.zbag", "*.zbag.key"], "wallet generato a runtime da `create-wallet`, mai in git")
        if UNTRACK_SEC: untrack("node_wallet.zbag", "segreto")
    untrack_dirs(r"^target(?=/)", "build Rust (target/)")
    if (ROOT / "target").exists(): ensure_gitignore("", ["target/"], "build Rust")

def annotate(rel, anchor_re, text):
    if rel not in FILES: return
    s = read(rel)
    if MARK in s: return
    lines = s.split("\n")
    for i, l in enumerate(lines):
        if re.search(anchor_re, l):
            ind = re.match(r"\s*", l).group(0)
            lines.insert(i, f"{ind}// {MARK}: {text}")
            write(rel, "\n".join(lines)); change(rel, "annotazione", text[:100]); return
def plug_zvalut():
    annotate("src/valut_core.zl", r"^\s*u64 balance_dsn;", "$DSN ha 18 decimali (ERC-20, Polygon 137): u64 in wei copre max ~18.44 DSN -> serve u128/u256 o unità ridotte; il valore 54000 è statico, non letto on-chain")
    finding("HIGH", "src/valut_core.zl", "balance_dsn hardcoded (54000) e tipo u64: non rappresenta un saldo reale")
def plug_zbag():
    annotate("src/chain_client.zl", r"chain_id:\s*7777", "$DSN vive su Polygon PoS chain 137 (contratto " + CONTRACT + "); 7777 è una chain ZDOS ipotetica, il saldo ZVT/DSN qui è simulato")

PLUGINS = {"aesir": plug_aesir, "ZDOS": plug_zdos, "xCLOUD-by-zdos": plug_xcloud, "Zdos-K.I.R.A": plug_kira,
           "zdos-hybrid": plug_hybrid, "zdos-organism": plug_organism, "Z-GENESIS-OS": plug_genesis,
           "Zlang": plug_zlang, "z-valut": plug_zvalut, "zBAG": plug_zbag}

if REPO in PLUGINS: PLUGINS[REPO]()
else: emit("info", msg="nessun plugin di ruolo: solo regole generiche")
if not IS_FORK:
    for rel in FILES:
        if rel not in OWNED: generic(rel)
scan_all()
for rel in changed: emit("changed", file=rel)
ENGINE_EOF

cat > "$TMP/report.py" <<'REPORT_EOF'
import json, sys
mode, path = sys.argv[1], sys.argv[2]
repo = sys.argv[3] if len(sys.argv) > 3 else ""
for line in open(path, encoding="utf-8"):
    d = json.loads(line)
    t = d["type"]
    if mode == "changed" and t == "changed":
        print(d["file"])
    elif mode == "untrack" and t == "untrack":
        print(d["file"])
    elif mode == "manifest" and t == "change":
        print("  - `%s` [%s] %s" % (d["file"], d["rule"], d["detail"]))
    elif mode == "audit" and t == "finding":
        where = ("`%s` " % d["file"]) if d["file"] else ""
        print("- [%s] **%s** %s%s" % (d["sev"], repo, where, d["msg"]))
REPORT_EOF

# ---------------------------------------------------------------- git
clone_url() { [[ $USE_SSH -eq 1 ]] && echo "git@github.com:$GH_OWNER/$1.git" || echo "https://github.com/$GH_OWNER/$1.git"; }

syntax_check() { # wt file -> 0/1
  local f="$1/$2"
  [[ -f "$f" ]] || return 0
  case "$2" in
    *.py) python3 -c 'import ast,sys; ast.parse(open(sys.argv[1]).read())' "$f" ;;
    *.sh|*.bash) bash -n "$f" ;;
    *.js|*.mjs|*.cjs)
      if command -v node >/dev/null; then
        node --check "$f" 2>/dev/null || { cp "$f" "$TMP/chk.mjs"; node --check "$TMP/chk.mjs"; }
      fi ;;
    *) return 0 ;;
  esac
}

MANIFEST="$WORKDIR/MANIFEST-CODE.md"
{
  echo "# MANIFEST — zdos-dsn-code-align v$VERSION"
  echo
  echo "- data: $(date '+%Y-%m-%d %H:%M %Z')"
  echo "- modo: $([[ $APPLY -eq 1 ]] && echo apply || echo dry-run)$([[ $PUSH -eq 1 ]] && echo ' + push')"
  echo "- contratto: $DSN_CONTRACT (chain $DSN_CHAIN_ID, $DSN_DECIMALS decimali)"
  echo "- RPC: $RPC_PRIMARY · $RPC_FALLBACK"
  echo
} > "$MANIFEST"
AUDIT="$TMP/audit.md"; : > "$AUDIT"
TOTAL=0; REPOS_CHANGED=""

process_repo() {
  local r="$1" dir="$WORKDIR/$1" defb base wt out n is_fork=0
  in_list "$r" "$NEVER_TOUCH" && { warn "$r: escluso"; return 0; }
  in_list "$r" "$UPSTREAM_FORKS" && is_fork=1
  log "== $r$([[ $is_fork -eq 1 ]] && echo ' (fork: solo plugin)')"
  if [[ ! -d "$dir/.git" ]]; then
    [[ $FETCH -eq 1 ]] || { warn "$r: clone assente e --no-fetch"; return 0; }
    git clone -q --filter=blob:none "$(clone_url "$r")" "$dir" || { warn "$r: clone fallito"; return 0; }
  elif [[ $FETCH -eq 1 ]]; then
    git -C "$dir" fetch -q origin '+refs/heads/*:refs/remotes/origin/*' || warn "$r: fetch fallito, uso lo stato locale"
  fi
  git -C "$dir" remote set-head origin --auto >/dev/null 2>&1 || true
  defb="$(git -C "$dir" symbolic-ref --short refs/remotes/origin/HEAD 2>/dev/null | sed 's#^origin/##')"
  [[ -n "$defb" ]] || defb="$(git -C "$dir" rev-parse --abbrev-ref HEAD)"
  [[ "$defb" != "$BRANCH" ]] || die "$r: il branch di default è $BRANCH?"
  if git -C "$dir" rev-parse -q --verify "refs/remotes/origin/$BRANCH" >/dev/null; then base="origin/$BRANCH"
  elif git -C "$dir" rev-parse -q --verify "refs/remotes/origin/$defb" >/dev/null; then base="origin/$defb"
  else base="$defb"; fi
  wt="$TMP/wt/$r"; echo "$dir" > "$wt.repo"
  if [[ $APPLY -eq 1 ]]; then
    if [[ "$(git -C "$dir" rev-parse --abbrev-ref HEAD)" == "$BRANCH" ]]; then
      warn "$r: $BRANCH è checkout nel clone principale: faccio checkout di $defb lì prima"; return 0
    fi
    git -C "$dir" worktree add -q -B "$BRANCH" "$wt" "$base"
  else
    git -C "$dir" worktree add -q --detach "$wt" "$base"
  fi
  out="$TMP/$r.jsonl"
  ( cd "$wt" && export IS_FORK=$is_fork UNTRACK_ARTIFACTS UNTRACK_SECRETS \
      DSN_CONTRACT RPC_PRIMARY RPC_FALLBACK MARK VERSION DSN_NAME DSN_CHAIN DSN_CHAIN_ID DSN_DECIMALS DSN_PORTAL DSN_EXPLORER \
      && python3 "$TMP/engine.py" "$r" "$wt" "$TMP/tpl" ) > "$out" || { warn "$r: engine fallito"; return 0; }

  local bad=0 f
  while IFS= read -r f; do
    syntax_check "$wt" "$f" || { warn "$r: syntax check FALLITO su $f -> repo annullato"; bad=1; }
  done < <(python3 "$TMP/report.py" changed "$out")
  if [[ $bad -eq 1 ]]; then git -C "$wt" checkout -q -- . ; git -C "$wt" clean -fdq; echo "- **$r**: annullato per syntax check fallito" >> "$AUDIT"; return 0; fi

  # untrack (solo con flag; engine li emette già filtrati)
  python3 "$TMP/report.py" untrack "$out" | while IFS= read -r f; do
      git -C "$wt" rm -r -q --cached -- "$f" >/dev/null 2>&1 && echo "untrack $f" >> "$out.untracked" || true
  done

  git -C "$wt" add -A
  n="$(git -C "$wt" diff --cached --name-only | wc -l | tr -d ' ')"
  {
    echo "## $r"
    echo
    echo "- base: \`$base\` @ $(git -C "$wt" rev-parse --short HEAD)$([[ $is_fork -eq 1 ]] && echo ' · fork: regole generiche disattivate')"
    echo "- file modificati: $n"
    python3 "$TMP/report.py" manifest "$out"
    [[ -f "$out.untracked" ]] && sed 's/^/  - git rm --cached: /' "$out.untracked" | sort -u | head -50
    echo
  } >> "$MANIFEST"
  python3 "$TMP/report.py" audit "$out" "$r" >> "$AUDIT"

  if [[ "$n" -eq 0 ]]; then ok "$r: già allineato (nessuna modifica)"; return 0; fi
  TOTAL=$((TOTAL + n)); REPOS_CHANGED="$REPOS_CHANGED $r"
  if [[ $APPLY -eq 0 ]]; then
    git -C "$wt" --no-pager diff --cached --stat -- . ':(exclude)zdos-llm' ':(exclude)**/__pycache__/**' | tail -25 || true
    git -C "$wt" --no-pager diff --cached --no-color -- . ':(exclude)zdos-llm' ':(exclude)**/__pycache__/**' ':(exclude)policy/target' ':(exclude)target' | head -400 || true
    return 0
  fi
  git -C "$wt" -c user.name="$(git -C "$dir" config user.name || echo high-cde)" \
      -c user.email="$(git -C "$dir" config user.email || echo high-cde@users.noreply.github.com)" \
      commit -q -m "chore(dsn): code-level alignment to \$DSN / NETkali (Polygon 137)" \
      -m "Generated by zdos-dsn-code-align.sh v$VERSION. Contract $DSN_CONTRACT, 18 decimals. RPC: publicnode + dRPC. See MANIFEST-CODE.md."
  ok "$r: commit $(git -C "$wt" rev-parse --short HEAD) su $BRANCH ($n file)"
  if [[ $PUSH -eq 1 ]]; then
    git -C "$dir" push --dry-run origin "refs/heads/$BRANCH:refs/heads/$BRANCH" >/dev/null 2>&1 \
      && git -C "$dir" push origin "refs/heads/$BRANCH:refs/heads/$BRANCH" \
      && ok "$r: push $BRANCH (apri la PR da GitHub)" || warn "$r: push rifiutato (serve --ssh/credenziali; mai --force)"
  fi
}

for r in $REPOS; do process_repo "$r"; done

{
  echo "## AUDIT — non automatizzabile in modo sicuro (serve una persona o un cloud agent)"
  echo
  for sev in CRIT HIGH MED LOW; do grep -F -- "- [$sev]" "$AUDIT" || true; done
  echo
  echo "Totale file modificati: $TOTAL · repo:${REPOS_CHANGED:- nessuno}"
} >> "$MANIFEST"

echo
log "MANIFEST: $MANIFEST"
cat "$MANIFEST"
echo
if [[ $APPLY -eq 0 ]]; then
  log "dry-run: nulla committato. Per applicare: $0 --apply   (poi --apply --push --ssh per pubblicare il branch $BRANCH)"
else
  log "commit su $BRANCH nei clone di $WORKDIR. Verifica con: git -C $WORKDIR/<repo> log -1 -p $BRANCH"
fi
