# ZDOS × $DSN — Mission Board

> First principles. Ship. Iterate. Make useful things inevitable.
> Inspired by the *build cadence* of ambitious engineering orgs — not affiliated with any third party.

## Token
| | |
|---|---|
| **Name** | NETkali |
| **Symbol** | `$DSN` |
| **Chain** | Polygon |
| **Contract** | `0xfc90516a1f736FaC557e09D8853dB80dA192c296` |
| **Role** | Access · Identity · Internal unit of account for ZDOS |
| **Portal** | https://x-zdos.it/dsn |
| **Explorer** | https://polygonscan.com/token/0xfc90516a1f736FaC557e09D8853dB80dA192c296 |

![DSN](./brand/dsn-badge.svg)

## Stack map (your repos → $DSN)

```
                    ┌──────────────────────┐
                    │   $DSN / NETkali     │
                    │  Polygon access key  │
                    └──────────┬───────────┘
           ┌───────────────────┼───────────────────┐
           ▼                   ▼                   ▼
     ┌──────────┐       ┌────────────┐      ┌─────────────┐
     │   ZDOS   │       │  xCLOUD    │      │  Z-GENESIS  │
     │  kernel  │       │  by-zdos   │      │     OS      │
     └────┬─────┘       └─────┬──────┘      └──────┬──────┘
          │                   │                    │
   ┌──────┴──────┐     ┌──────┴──────┐      ┌──────┴──────┐
   │ Zlang/core  │     │  zBAG wallet│      │ aesir/KIRA  │
   │ hybrid/lab  │     │  unified web│      │ zclipper    │
   └─────────────┘     └─────────────┘      └─────────────┘
```

### Attach these READMEs (copy block)

```markdown
## $DSN · NETkali
Access layer of the ZDOS ecosystem on Polygon.
- Contract: `0xfc90516a1f736FaC557e09D8853dB80dA192c296`
- Portal: https://x-zdos.it/dsn
- Explorer: https://polygonscan.com/token/0xfc90516a1f736FaC557e09D8853dB80dA192c296

![DSN](https://img.shields.io/badge/%24DSN-NETkali%20%7C%20Polygon-6ee7ff?style=flat-square&labelColor=0b0e16)
```

### Priority repos to stamp first
1. `ZDOS` · `zdos-core` · `xCLOUD-by-zdos`
2. `Zlang` · `zlang-core` · `z-valut`
3. `zBAG` · `xzdos-unified-webapp` · `x-zdos.it`
4. `Z-GENESIS-OS` · `aesir` · `zclipper` · `Zdos-K.I.R.A`

## Honest market note
Public pools exist but liquidity is dust (~$0.3) and 24h volume ≈ 0.
Value path: **utility gate → one serious LP → external users**. No wash, no fake TVL.

## VPS: find the live index
```bash
# 1) nginx / caddy / apache vhosts
sudo grep -R "root\|server_name\|x-zdos" /etc/nginx /etc/caddy /etc/apache2 /etc/httpd 2>/dev/null | head -n 80

# 2) find every index.html under common web roots
sudo find /var/www /srv /home /opt /usr/share/nginx -type f \( -name 'index.html' -o -name 'index.php' \) 2>/dev/null

# 3) what is listening on 80/443
sudo ss -tlnp | grep -E ':80|:443'

# 4) if dockerized
docker ps --format 'table {{.Names}}\t{{.Ports}}\t{{.Image}}'
docker inspect $(docker ps -q) 2>/dev/null | grep -E 'x-zdos|/var/www|HostConfig|Source' | head -n 60
```

Deploy `/dsn`:
```bash
# after you know WEBROOT from the commands above, e.g. /var/www/x-zdos.it
sudo mkdir -p "$WEBROOT/dsn"
sudo cp index.html "$WEBROOT/dsn/index.html"
# reload if needed
sudo nginx -t && sudo systemctl reload nginx
```
