# $DSN page for x-zdos.it

Upload `index.html` as:
- `https://x-zdos.it/dsn/index.html` (folder `/dsn`)
or rename/copy into your static host so it serves at `/dsn`.

Honest token page: contract, utility, live liquidity truth, roadmap.
No price promises.
