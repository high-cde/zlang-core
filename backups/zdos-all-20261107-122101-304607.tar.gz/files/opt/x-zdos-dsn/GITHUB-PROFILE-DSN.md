### ZDOS constellation powered by `$DSN`

```text
MISSION: make delay zero · keep sovereignty · ship weekly
TOKEN:   $DSN / NETkali @ Polygon 0xfc90516a1f736FaC557e09D8853dB80dA192c296
PORTAL:  https://x-zdos.it
```

**Core**
- [ZDOS](https://github.com/high-cde/ZDOS) · [zdos-core](https://github.com/high-cde/zdos-core) · [Zlang](https://github.com/high-cde/Zlang)

**Cloud & wallet**
- [xCLOUD-by-zdos](https://github.com/high-cde/xCLOUD-by-zdos) · [zBAG](https://github.com/high-cde/zBAG) · [xzdos-unified-webapp](https://github.com/high-cde/xzdos-unified-webapp)

**Agents & OS**
- [aesir](https://github.com/high-cde/aesir) · [Zdos-K.I.R.A](https://github.com/high-cde/Zdos-K.I.R.A) · [Z-GENESIS-OS](https://github.com/high-cde/Z-GENESIS-OS) · [zclipper](https://github.com/high-cde/zclipper)

**Lab**
- [zdos-hybrid](https://github.com/high-cde/zdos-hybrid) · [ZDOS-lab-v1](https://github.com/high-cde/ZDOS-lab-v1) · [xzdos-vps-bundle](https://github.com/high-cde/xzdos-vps-bundle)
